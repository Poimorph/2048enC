# 2048 en Langage C
a faire : 
- Programme Principale (Le jeu):
  *  Choix de la taille du jeu
  *  gestion des déplacement
  *  traking du score
  *  fusion des cases
  *  Spawn des cases 
- Interface graphique :
  *  Choix de la bibliothèque Graphique.
        Proposition : SDK ?
  *   affichage du score
  *   annimations des déplacements
  *   annimation de changement des valeurs de cases
  *   


Répartition actuel :
* Partie Graphique : Suhayb
* Les modes de jeu : Matteo
* Gestion de la sauvegarde : Alexis
